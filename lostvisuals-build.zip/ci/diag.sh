#!/usr/bin/env bash
# Выгружает реальные сигнатуры API Minecraft/Fabric из кэша Gradle сборки. Запускается из корня job'а (рядом tpl/ и mod/).
set -u
mkdir -p diag
ALL=$(find "$HOME/.gradle" tpl/.gradle tpl/build -name '*.jar' 2>/dev/null | sort -u)
echo "jars total: $(echo "$ALL" | wc -l)" > diag/jars.txt

# Индекс: "<jar>\t<class>" для всех jar (нужен, чтобы найти класс по простому имени)
: > /tmp/index.tsv
for j in $ALL; do
  unzip -Z1 "$j" 2>/dev/null | grep '\.class$' | sed "s|^|$j\t|" >> /tmp/index.tsv
done
echo "index lines: $(wc -l < /tmp/index.tsv)" >> diag/jars.txt

# Именованные (не intermediary) классы Minecraft: клиентские и общие
awk -F'\t' '$2 ~ /^net\/minecraft\// && $2 !~ /\$/ && $2 !~ /class_[0-9]+/ {print $2}' /tmp/index.tsv | sort -u | sed 's#\.class$##; s#/#.#g' > diag/mc_classes.txt
awk -F'\t' '$2 ~ /^com\/mojang\/blaze3d\// && $2 !~ /\$/ {print $2}' /tmp/index.tsv | sort -u | sed 's#\.class$##; s#/#.#g' > diag/blaze3d_classes.txt
awk -F'\t' '$2 ~ /^net\/fabricmc\/fabric\/api\/client\// && $2 !~ /\$/ {print $2}' /tmp/index.tsv | sort -u | sed 's#\.class$##; s#/#.#g' > diag/fabric_client_classes.txt
wc -l diag/*_classes.txt >> diag/jars.txt

CP=$(echo "$ALL" | tr '\n' ':')
: > diag/sigs.txt
: > diag/unresolved.txt
if ! command -v javap >/dev/null 2>&1; then echo "javap not found" >> diag/jars.txt; exit 0; fi
while read -r n; do
  [ -z "$n" ] && continue
  fq=$(awk -F'\t' -v n="$n" '$2 ~ ("/" n "\\.class$") && ($2 ~ /^net\/minecraft\// || $2 ~ /^com\/mojang\// || $2 ~ /^net\/fabricmc\// || $2 ~ /^org\/joml\//) && $2 !~ /class_[0-9]+/ {print $2}' /tmp/index.tsv | sort -u | sed 's#\.class$##; s#/#.#g')
  if [ -z "$fq" ]; then echo "$n" >> diag/unresolved.txt; continue; fi
  for c in $fq; do
    echo "#### $c" >> diag/sigs.txt
    javap -protected -cp "$CP" "$c" >> diag/sigs.txt 2>&1
  done
done < mod/ci/names.txt
ls -la diag
