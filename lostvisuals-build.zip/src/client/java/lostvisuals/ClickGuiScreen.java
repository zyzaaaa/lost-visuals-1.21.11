package lostvisuals;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;

/** Меню Lost Visuals: боковая панель со страницами и сетка карточек модулей. Открывается на правый Shift. */
public class ClickGuiScreen extends Screen {
    private static final Identifier LOGO = Identifier.fromNamespaceAndPath("lostvisuals", "textures/gui/logo.png");

    private static final int SIDEBAR_W = 124;
    private static final int PAD = 12;
    private static final int GAP = 8;
    private static final int CARD_BASE_TOP = 22;
    private static final int LINE_H = 10;

    private final long openedAt = System.currentTimeMillis();

    private ModuleManager.Page currentPage = ModuleManager.ALL_PAGES.get(0);
    private int columns = 2;
    private int scroll = 0;
    private int contentHeight = 0;

    // Прямоугольники, пересчитываются каждый кадр в render()
    private record Hit(int x, int y, int w, int h, boolean clipped, Runnable action) {}
    private final List<Hit> hits = new ArrayList<>();
    private int viewX, viewY, viewW, viewH;
    private int winX, winY, winW, winH;

    public ClickGuiScreen() {
        super(Component.literal("Lost Visuals"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private Font f() {
        return this.font;
    }

    private void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(f(), s, x, y, color);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        hits.clear();
        int gw = g.guiWidth();
        int gh = g.guiHeight();
        winW = Math.min(gw - 24, 620);
        winH = Math.min(gh - 20, 340);
        winX = (gw - winW) / 2;
        winY = (gh - winH) / 2;

        Draw.rrectBordered(g, winX, winY, winW, winH, 6, Draw.WINDOW_BG, Draw.WINDOW_BORDER);
        drawSidebar(g, mouseX, mouseY);
        drawHeader(g, mouseX, mouseY);
        drawContent(g, mouseX, mouseY);
    }

    private void drawSidebar(GuiGraphics g, int mx, int my) {
        int sx = winX + 1;
        int sy = winY + 1;
        int sh = winH - 2;
        g.fill(sx, sy + 6, sx + SIDEBAR_W, sy + sh - 6, Draw.SIDEBAR_BG);
        g.fill(sx + SIDEBAR_W, sy + 6, sx + SIDEBAR_W + 1, sy + sh - 6, Draw.WINDOW_BORDER);

        g.blit(RenderPipelines.GUI_TEXTURED, LOGO, winX + PAD, winY + PAD, 0f, 0f, 22, 22, 256, 256, 256, 256);
        text(g, "Lost Visuals", winX + PAD + 28, winY + PAD + 2, Draw.TEXT);
        text(g, "v0.1 · 1.21.11", winX + PAD + 28, winY + PAD + 13, Draw.TEXT_DIM);

        int y = winY + 46;
        for (var entry : ModuleManager.GROUPS.entrySet()) {
            text(g, entry.getKey(), winX + PAD, y, Draw.TEXT_DIM);
            y += 14;
            for (ModuleManager.Page p : entry.getValue()) {
                int rx = winX + 6;
                int rw = SIDEBAR_W - 10;
                boolean selected = p == currentPage;
                boolean hover = Draw.inside(mx, my, rx, y - 3, rw, 18);
                if (selected) {
                    Draw.rrect(g, rx, y - 3, rw, 18, 4, Draw.ACCENT_SOFT);
                } else if (hover) {
                    Draw.rrect(g, rx, y - 3, rw, 18, 4, Draw.BUTTON_BG);
                }
                g.fill(winX + PAD, y + 1, winX + PAD + 5, y + 6, selected ? Draw.ACCENT : Draw.SWITCH_OFF);
                text(g, p.name, winX + PAD + 12, y, selected ? Draw.TEXT : Draw.TEXT_DIM);
                final ModuleManager.Page target = p;
                hits.add(new Hit(rx, y - 3, rw, 18, false, () -> {
                    currentPage = target;
                    scroll = 0;
                }));
                y += 20;
            }
            y += 6;
        }
    }

    private void drawHeader(GuiGraphics g, int mx, int my) {
        int hx = winX + SIDEBAR_W + PAD;
        int hy = winY + PAD;
        text(g, currentPage.group + " / ", hx, hy + 4, Draw.TEXT_DIM);
        int gx = hx + f().width(currentPage.group + " / ");
        text(g, currentPage.name, gx, hy + 4, Draw.TEXT);

        String collapse = "Свернуть всё";
        String view = "Отображение";
        int viewBtnW = f().width(view) + 12 + 14;
        int collapseBtnW = f().width(collapse) + 12;
        int right = winX + winW - PAD;
        int vbx = right - viewBtnW;
        int cbx = vbx - GAP - collapseBtnW;

        boolean hc = Draw.inside(mx, my, cbx, hy, collapseBtnW, 16);
        Draw.rrect(g, cbx, hy, collapseBtnW, 16, 4, hc ? Draw.CARD_BORDER : Draw.BUTTON_BG);
        text(g, collapse, cbx + 6, hy + 4, Draw.TEXT);
        hits.add(new Hit(cbx, hy, collapseBtnW, 16, false, () -> {
            for (ModuleManager.Page p : ModuleManager.ALL_PAGES) {
                for (Module m : p.modules) m.expanded = false;
            }
            scroll = 0;
        }));

        boolean hv = Draw.inside(mx, my, vbx, hy, viewBtnW, 16);
        Draw.rrect(g, vbx, hy, viewBtnW, 16, 4, hv ? Draw.CARD_BORDER : Draw.BUTTON_BG);
        text(g, view, vbx + 6, hy + 4, Draw.TEXT);
        Draw.rrect(g, vbx + viewBtnW - 16, hy + 3, 10, 10, 3, Draw.ACCENT);
        text(g, String.valueOf(columns), vbx + viewBtnW - 13, hy + 4, 0xFF0D0E10);
        hits.add(new Hit(vbx, hy, viewBtnW, 16, false, () -> {
            columns = columns == 2 ? 1 : 2;
            scroll = 0;
        }));
    }

    private void drawContent(GuiGraphics g, int mx, int my) {
        viewX = winX + SIDEBAR_W + PAD;
        viewY = winY + PAD + 26;
        viewW = winX + winW - PAD - viewX;
        viewH = winY + winH - PAD - viewY;

        List<Module> mods = currentPage.modules;
        if (mods.isEmpty()) {
            String msg = "Здесь пока пусто";
            g.drawString(f(), msg, viewX + (viewW - f().width(msg)) / 2, viewY + viewH / 2 - 4, Draw.TEXT_DIM);
            contentHeight = 0;
            return;
        }

        int cols = Math.max(1, columns);
        int cardW = (viewW - 6 - GAP * (cols - 1)) / cols;
        int[] colY = new int[cols];

        g.enableScissor(viewX, viewY, viewX + viewW, viewY + viewH);
        for (Module m : mods) {
            int c = 0;
            for (int i = 1; i < cols; i++) {
                if (colY[i] < colY[c]) c = i;
            }
            int cx = viewX + c * (cardW + GAP);
            int cy = viewY + colY[c] - scroll;
            int ch = drawCard(g, m, cx, cy, cardW, mx, my);
            colY[c] += ch + GAP;
        }
        g.disableScissor();

        int maxY = 0;
        for (int v : colY) maxY = Math.max(maxY, v);
        contentHeight = maxY;
        int maxScroll = Math.max(0, contentHeight - viewH);
        if (scroll > maxScroll) scroll = maxScroll;
        if (scroll < 0) scroll = 0;
    }

    /** Рисует карточку, регистрирует клики, возвращает её высоту. */
    private int drawCard(GuiGraphics g, Module m, int x, int y, int w, int mx, int my) {
        List<FormattedCharSequence> lines = f().split(Component.literal(descriptionOf(m)), w - 24);
        int shown = Math.min(2, lines.size());
        int h = CARD_BASE_TOP + shown * LINE_H + 10;
        if (m.expanded) h += 4 + m.settings.size() * 18 + (m.settings.isEmpty() ? 14 : 0);

        boolean cardHover = Draw.inside(mx, my, x, y, w, h)
                && Draw.inside(mx, my, viewX, viewY, viewW, viewH);
        Draw.rrectBordered(g, x, y, w, h, 5, cardHover ? 0xFF1B1C21 : Draw.CARD_BG, Draw.CARD_BORDER);

        text(g, m.name, x + 12, y + 8, Draw.TEXT);
        for (int i = 0; i < shown; i++) {
            g.drawString(f(), lines.get(i), x + 12, y + CARD_BASE_TOP + i * LINE_H, Draw.TEXT_DIM);
        }

        int arrowX = x + w - 10 - 14;
        int toggleX = arrowX - 8 - 22;
        Draw.toggle(g, toggleX, y + 8, m.enabled);
        text(g, m.expanded ? "v" : ">", arrowX + 4, y + 9, Draw.TEXT_DIM);

        Runnable toggleAction = () -> {
            m.enabled = !m.enabled;
            ModuleManager.save();
        };
        Runnable arrowAction = () -> m.expanded = !m.expanded;
        hits.add(new Hit(toggleX, y + 6, 22, 16, true, toggleAction));
        hits.add(new Hit(arrowX, y + 6, 14, 16, true, arrowAction));

        if (m.expanded) {
            int sy = y + CARD_BASE_TOP + shown * LINE_H + 8;
            g.fill(x + 12, sy - 2, x + w - 12, sy - 1, Draw.CARD_BORDER);
            if (m.settings.isEmpty()) {
                text(g, "Настроек пока нет", x + 12, sy + 3, Draw.TEXT_DIM);
            }
            for (BoolSetting s : m.settings) {
                text(g, s.name, x + 12, sy + 4, Draw.TEXT);
                int tx = x + w - 12 - 22;
                Draw.toggle(g, tx, sy + 2, s.value);
                hits.add(new Hit(tx, sy, 22, 16, true, () -> {
                    s.value = !s.value;
                    ModuleManager.save();
                }));
                sy += 18;
            }
        }
        return h;
    }

    private String descriptionOf(Module m) {
        return m.implemented ? m.description : m.description + " (скоро)";
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!Draw.inside(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.clipped() && !Draw.inside(mx, my, viewX, viewY, viewW, viewH)) continue;
            h.action().run();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (Draw.inside(mouseX, mouseY, viewX, viewY, viewW, viewH)) {
            int maxScroll = Math.max(0, contentHeight - viewH);
            scroll = Math.max(0, Math.min(maxScroll, scroll - (int) Math.round(scrollY * 18)));
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == InputConstants.KEY_RSHIFT && System.currentTimeMillis() - openedAt > 300) {
            this.onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void removed() {
        ModuleManager.save();
        super.removed();
    }
}
