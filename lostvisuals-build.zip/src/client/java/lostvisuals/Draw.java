package lostvisuals;

import net.minecraft.client.gui.GuiGraphics;

/** Мелкие помощники рисования и палитра. Цвета в формате ARGB. */
public final class Draw {
    private Draw() {}

    public static final int WINDOW_BG = 0xF2101114;
    public static final int WINDOW_BORDER = 0xFF26272C;
    public static final int SIDEBAR_BG = 0xFF0D0E10;
    public static final int CARD_BG = 0xFF17181C;
    public static final int CARD_BORDER = 0xFF25272C;
    public static final int TEXT = 0xFFF2F3F5;
    public static final int TEXT_DIM = 0xFF8A8D94;
    public static final int ACCENT = 0xFF2EA8FF;
    public static final int ACCENT_SOFT = 0x332EA8FF;
    public static final int SWITCH_OFF = 0xFF3A3C42;
    public static final int KNOB = 0xFFE9EAEE;
    public static final int BUTTON_BG = 0xFF1B1C20;

    /** Скруглённый прямоугольник: только углы строками, середина одним fill. */
    public static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    /** Скруглённый прямоугольник с рамкой 1px. */
    public static void rrectBordered(GuiGraphics g, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(g, x, y, w, h, r, border);
        rrect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    /** Переключатель-«таблетка» 22x12. */
    public static void toggle(GuiGraphics g, int x, int y, boolean on) {
        rrect(g, x, y, 22, 12, 6, on ? ACCENT : SWITCH_OFF);
        int kx = on ? x + 12 : x + 2;
        rrect(g, kx, y + 2, 8, 8, 4, KNOB);
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
