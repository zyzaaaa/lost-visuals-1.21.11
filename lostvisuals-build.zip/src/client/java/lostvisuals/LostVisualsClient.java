package lostvisuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Точка входа Lost Visuals: меню открывается на правый Shift. */
public class LostVisualsClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("lostvisuals");

    private static boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Hud.register();
        TitleBackground.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean down = InputConstants.isKeyDown(client.getWindow(), InputConstants.KEY_RSHIFT);
            if (down && !wasDown && client.screen == null && client.player != null) {
                client.setScreen(new ClickGuiScreen());
            }
            wasDown = down;
        });
        LOG.info("Lost Visuals loaded");
    }
}
