package lostvisuals;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Точка входа Lost Visuals. Пока только проверка, что сборка и загрузка работают. */
public class LostVisualsClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("lostvisuals");

    @Override
    public void onInitializeClient() {
        LOG.info("Lost Visuals loaded");
    }
}
