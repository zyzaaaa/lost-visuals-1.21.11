package lostvisuals;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

/** Структура меню (группа -> страница -> модули) и сохранение состояния в config/lostvisuals.json. */
public final class ModuleManager {
    private ModuleManager() {}

    /** Группа -> страницы. Порядок вставки сохраняется. */
    public static final Map<String, List<Page>> GROUPS = new LinkedHashMap<>();
    public static final List<Page> ALL_PAGES = new ArrayList<>();

    public static final class Page {
        public final String group;
        public final String name;
        public final List<Module> modules = new ArrayList<>();

        Page(String group, String name) {
            this.group = group;
            this.name = name;
        }
    }

    public static Module WATERMARK;
    public static Module FPS;
    public static Module COORDS;
    public static Module TITLE_PHOTO;

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("lostvisuals.json");
    }

    private static Page page(String group, String name) {
        Page p = new Page(group, name);
        GROUPS.computeIfAbsent(group, g -> new ArrayList<>()).add(p);
        ALL_PAGES.add(p);
        return p;
    }

    public static void init() {
        Page render = page("Visuals", "Render");
        render.modules.add(new Module("Fullbright", "Максимальная яркость мира", false, false));
        render.modules.add(new Module("Zoom", "Приближение камеры по клавише", false, false));
        render.modules.add(new Module("No Hurt Cam", "Убирает тряску камеры при уроне", false, false));

        Page esp = page("Visuals", "ESP");
        esp.modules.add(new Module("Player ESP", "Подсветка игроков вокруг", false, false));
        esp.modules.add(new Module("Item ESP", "Подсветка выпавших предметов", false, false));
        esp.modules.add(new Module("Chest ESP", "Подсветка сундуков", false, false));

        Page display = page("Visuals", "Display");
        WATERMARK = new Module("Watermark", "Название клиента в углу экрана", true, true).bool("Показывать версию", true);
        FPS = new Module("FPS Counter", "Счётчик кадров в секунду", true, true);
        COORDS = new Module("Coordinates", "Координаты игрока на экране", true, false).bool("Округлять", true);
        display.modules.add(WATERMARK);
        display.modules.add(FPS);
        display.modules.add(COORDS);
        display.modules.add(new Module("Armor HUD", "Состояние брони на экране", false, false));

        page("Settings", "Configs");
        Page misc = page("Settings", "Miscellaneous");
        TITLE_PHOTO = new Module("Title Photo", "Фото на фоне главного экрана", true, true);
        misc.modules.add(TITLE_PHOTO);

        load();
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Page p : ALL_PAGES) {
                for (Module m : p.modules) {
                    JsonObject mo = new JsonObject();
                    mo.addProperty("enabled", m.enabled);
                    JsonObject so = new JsonObject();
                    for (BoolSetting s : m.settings) so.addProperty(s.name, s.value);
                    mo.add("settings", so);
                    root.add(m.name, mo);
                }
            }
            Files.writeString(configPath(), root.toString());
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось сохранить конфиг: {}", e.toString());
        }
    }

    private static void load() {
        Path path = configPath();
        if (!Files.isRegularFile(path)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
            for (Page p : ALL_PAGES) {
                for (Module m : p.modules) {
                    if (!root.has(m.name) || !root.get(m.name).isJsonObject()) continue;
                    JsonObject mo = root.getAsJsonObject(m.name);
                    if (mo.has("enabled")) m.enabled = mo.get("enabled").getAsBoolean();
                    if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                        JsonObject so = mo.getAsJsonObject("settings");
                        for (BoolSetting s : m.settings) {
                            if (so.has(s.name)) s.value = so.get(s.name).getAsBoolean();
                        }
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось прочитать конфиг, беру значения по умолчанию: {}", e.toString());
        }
    }
}
