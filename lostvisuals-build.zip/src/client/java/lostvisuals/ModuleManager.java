package lostvisuals;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

/** Структура меню (группа -> страница -> модули) и сохранение состояния в config/lostvisuals.json. */
public final class ModuleManager {
    private ModuleManager() {}

    /** Группа -> страницы. Порядок вставки сохраняется. */
    public static final Map<String, List<Page>> GROUPS = new LinkedHashMap<>();
    public static final List<Page> ALL_PAGES = new ArrayList<>();

    public static final class Page {
        public final String group;
        public final String name;
        public final List<Module> modules = new ArrayList<>();

        Page(String group, String name) {
            this.group = group;
            this.name = name;
        }
    }

    public static Module WATERMARK;
    public static Module FPS;
    public static Module COORDS;
    public static Module ARMOR;
    public static Module KEYS;
    public static Module TARGET;
    public static Module SPEED;
    public static Module CLOCK;
    public static Module TITLE_PHOTO;
    public static Module BOOST;
    public static Module THEME;

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("lostvisuals.json");
    }

    private static Page page(String group, String name) {
        Page p = new Page(group, name);
        GROUPS.computeIfAbsent(group, g -> new ArrayList<>()).add(p);
        ALL_PAGES.add(p);
        return p;
    }

    public static void init() {
        Page render = page("Visuals", "Render");
        BOOST = new Module("FPS Boost", "Минимальная нагрузка на графику для максимума FPS", true, false);
        for (String name : Boost.SETTINGS) BOOST.bool(name, true);
        BOOST.onChange = Boost::sync;
        render.modules.add(BOOST);
        render.modules.add(new Module("Fullbright", "Максимальная яркость мира", false, false));
        render.modules.add(new Module("Zoom", "Приближение камеры по клавише", false, false));
        render.modules.add(new Module("No Hurt Cam", "Убирает тряску камеры при уроне", false, false));

        // Косметические визуальные модули. Пока представлены настройками меню;
        // для 3D-рендера аксессуаров потребуется отдельный render layer.
        Page cosmetics = page("Visuals", "Cosmetics");
        cosmetics.modules.add(new Module("Shoulder Pet", "Декоративный питомец на плече", false, false)
                .choice("Питомец", 0, "Parrot", "Mini Allay", "Mini Bee", "Mini Slime")
                .choice("Позиция", 0, "Left", "Right"));
        cosmetics.modules.add(new Module("Cape", "Декоративный плащ за персонажем", false, false)
                .choice("Материал", 0, "Neon", "Metallic", "Holographic", "Carbon")
                .choice("Узор", 0, "なし", "Waves", "Lightning", "Grid"));
        cosmetics.modules.add(new Module("Hat", "Шляпы и головные аксессуары", false, false)
                .choice("Модель", 0, "Top Hat", "Crown", "Bucket Hat", "Wizard")
                .choice("Материал", 0, "Metallic", "Neon", "Glass"));
        cosmetics.modules.add(new Module("Halo", "Светящийся декоративный обруч над головой", false, false)
                .choice("Стиль", 0, "Neon", "Chrome", "RGB"));

        Page sky = page("Visuals", "Sky");
        sky.modules.add(new Module("Sky Shader", "Кастомный градиент неба, туманность и сияние (шейдер загружается ресурсом)", false, false)
                .choice("Палитра", 0, "Purple Neon", "Cyber Blue", "Emerald", "Sunset", "Metallic")
                .choice("Эффект", 0, "Aurora", "Nebula", "Stars", "Clean Gradient"));

        Page esp = page("Visuals", "ESP");
        esp.modules.add(new Module("Player ESP", "Подсветка игроков вокруг", false, false));
        esp.modules.add(new Module("Item ESP", "Подсветка выпавших предметов", false, false));
        esp.modules.add(new Module("Chest ESP", "Подсветка сундуков", false, false));

        Page display = page("Visuals", "Display");
        WATERMARK = new Module("Watermark", "Название клиента в углу экрана", true, true).bool("Показывать версию", true);
        FPS = new Module("FPS Counter", "Счётчик кадров в секунду", true, true);
        COORDS = new Module("Coordinates", "Координаты игрока на экране", true, false).bool("Округлять", true);
        display.modules.add(WATERMARK);
        display.modules.add(FPS);
        display.modules.add(COORDS);
        ARMOR = new Module("Armor HUD", "Броня с прочностью на экране", true, true).bool("Показывать прочность", true);
        KEYS = new Module("Keystrokes", "Нажатые клавиши движения и мыши", true, false).bool("Показывать мышь", true);
        TARGET = new Module("Target HUD", "Имя и здоровье существа под прицелом", true, true);
        SPEED = new Module("Speed", "Горизонтальная скорость в блоках в секунду", true, false);
        CLOCK = new Module("Clock", "Реальное время на экране", true, false).bool("24 часа", true);
        display.modules.add(ARMOR);
        display.modules.add(KEYS);
        display.modules.add(TARGET);
        display.modules.add(SPEED);
        display.modules.add(CLOCK);

        page("Settings", "Configs");
        Page misc = page("Settings", "Miscellaneous");
        THEME = new Module("Theme", "Стиль и цвет меню и экранных модулей: неон, металлик, стекло", true, true)
                .choice("Стиль", 1, "Default", "Neon", "Metallic", "Glass")
                .choice("Акцент", 0, "Blue", "Purple", "Green", "Red", "Pink", "Orange", "Rainbow");
        THEME.onChange = Theme::apply;
        misc.modules.add(THEME);
        TITLE_PHOTO = new Module("Title Photo", "Фото на фоне главного экрана", true, true);
        misc.modules.add(TITLE_PHOTO);

        load();
        Theme.apply();
    }

    private static Path profilesDir() {
        return FabricLoader.getInstance().getConfigDir().resolve("lostvisuals").resolve("profiles");
    }

    private static JsonObject toJson() {
        JsonObject root = new JsonObject();
        for (Page p : ALL_PAGES) {
            for (Module m : p.modules) {
                JsonObject mo = new JsonObject();
                mo.addProperty("enabled", m.enabled);
                JsonObject so = new JsonObject();
                for (BoolSetting s : m.settings) so.addProperty(s.name, s.value);
                mo.add("settings", so);
                JsonObject co = new JsonObject();
                for (ChoiceSetting c : m.choices) co.addProperty(c.name, c.index);
                mo.add("choices", co);
                root.add(m.name, mo);
            }
        }
        return root;
    }

    private static void applyJson(JsonObject root) {
        for (Page p : ALL_PAGES) {
            for (Module m : p.modules) {
                if (!root.has(m.name) || !root.get(m.name).isJsonObject()) continue;
                JsonObject mo = root.getAsJsonObject(m.name);
                if (mo.has("enabled")) m.enabled = mo.get("enabled").getAsBoolean();
                if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (BoolSetting s : m.settings) {
                        if (so.has(s.name)) s.value = so.get(s.name).getAsBoolean();
                    }
                }
                if (mo.has("choices") && mo.get("choices").isJsonObject()) {
                    JsonObject co = mo.getAsJsonObject("choices");
                    for (ChoiceSetting c : m.choices) {
                        if (co.has(c.name)) {
                            int i = co.get(c.name).getAsInt();
                            if (i >= 0 && i < c.options.length) c.index = i;
                        }
                    }
                }
            }
        }
    }

    public static void save() {
        try {
            Files.writeString(configPath(), toJson().toString());
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось сохранить конфиг: {}", e.toString());
        }
    }

    private static void load() {
        Path path = configPath();
        if (!Files.isRegularFile(path)) return;
        try {
            applyJson(JsonParser.parseString(Files.readString(path)).getAsJsonObject());
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось прочитать конфиг, беру значения по умолчанию: {}", e.toString());
        }
    }

    // ---- профили конфигов ----

    private static String sanitize(String name) {
        String n = name.replaceAll("[^a-zA-Z0-9_\\- ]", "").trim();
        return n.isEmpty() ? "profile" : n;
    }

    public static List<String> listProfiles() {
        List<String> out = new ArrayList<>();
        Path dir = profilesDir();
        if (!Files.isDirectory(dir)) return out;
        try (var stream = Files.list(dir)) {
            stream.map(x -> x.getFileName().toString())
                    .filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5))
                    .forEach(out::add);
        } catch (IOException e) {
            LostVisualsClient.LOG.warn("Не удалось прочитать список профилей: {}", e.toString());
        }
        Collections.sort(out);
        return out;
    }

    public static String nextProfileName() {
        List<String> existing = listProfiles();
        for (int i = 1; i < 1000; i++) {
            String n = "profile-" + i;
            if (!existing.contains(n)) return n;
        }
        return "profile-" + System.currentTimeMillis();
    }

    public static boolean saveProfile(String name) {
        try {
            Files.createDirectories(profilesDir());
            Files.writeString(profilesDir().resolve(sanitize(name) + ".json"), toJson().toString());
            return true;
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось сохранить профиль: {}", e.toString());
            return false;
        }
    }

    public static boolean loadProfile(String name) {
        Path path = profilesDir().resolve(sanitize(name) + ".json");
        try {
            applyJson(JsonParser.parseString(Files.readString(path)).getAsJsonObject());
            save();
            if (BOOST != null && BOOST.onChange != null) BOOST.onChange.run();
            Theme.apply();
            return true;
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось загрузить профиль: {}", e.toString());
            return false;
        }
    }

    public static boolean deleteProfile(String name) {
        try {
            return Files.deleteIfExists(profilesDir().resolve(sanitize(name) + ".json"));
        } catch (IOException e) {
            LostVisualsClient.LOG.warn("Не удалось удалить профиль: {}", e.toString());
            return false;
        }
    }
}
