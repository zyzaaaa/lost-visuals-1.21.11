package lostvisuals;

import java.util.ArrayList;
import java.util.List;

/** Модуль: карточка в меню. implemented=false значит «только интерфейс, функции пока нет». */
public final class Module {
    public final String name;
    public final String description;
    public final boolean implemented;
    public boolean enabled;
    public boolean expanded;
    public final List<BoolSetting> settings = new ArrayList<>();

    public Module(String name, String description, boolean implemented, boolean enabledByDefault) {
        this.name = name;
        this.description = description;
        this.implemented = implemented;
        this.enabled = enabledByDefault;
    }

    public Module bool(String settingName, boolean def) {
        settings.add(new BoolSetting(settingName, def));
        return this;
    }

    public boolean setting(String settingName) {
        for (BoolSetting s : settings) {
            if (s.name.equals(settingName)) return s.value;
        }
        return false;
    }
}
