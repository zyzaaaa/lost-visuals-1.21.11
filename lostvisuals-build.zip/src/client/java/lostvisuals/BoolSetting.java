package lostvisuals;

/** Простая настройка-переключатель внутри карточки модуля. */
public final class BoolSetting {
    public final String name;
    public boolean value;

    public BoolSetting(String name, boolean value) {
        this.name = name;
        this.value = value;
    }
}
