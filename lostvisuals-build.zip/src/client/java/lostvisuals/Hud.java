package lostvisuals;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** Экранные модули: плашки слева сверху, броня справа, клавиши внизу слева, цель у прицела. */
public final class Hud {
    private Hud() {}

    private static final DateTimeFormatter CLOCK_24 = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter CLOCK_12 = DateTimeFormatter.ofPattern("hh:mm a");
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("lostvisuals", "hud"), (g, deltaTracker) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            drawPills(g, mc);
            if (ModuleManager.ARMOR.enabled) drawArmor(g, mc);
            if (ModuleManager.KEYS.enabled) drawKeys(g, mc);
            if (ModuleManager.TARGET.enabled) drawTarget(g, mc);
        });
    }

    // ---- плашки слева сверху ----

    private static void drawPills(GuiGraphics g, Minecraft mc) {
        int y = 6;
        if (ModuleManager.WATERMARK.enabled) {
            String t = "Lost Visuals";
            if (ModuleManager.WATERMARK.setting("Показывать версию")) t += " 1.21.11";
            y = pill(g, mc.font, t, 6, y, true);
        }
        if (ModuleManager.FPS.enabled) {
            y = pill(g, mc.font, mc.getFps() + " FPS", 6, y, false);
        }
        if (ModuleManager.COORDS.enabled) {
            boolean round = ModuleManager.COORDS.setting("Округлять");
            double x = mc.player.getX();
            double yy = mc.player.getY();
            double z = mc.player.getZ();
            String t = round
                    ? "XYZ " + (int) Math.floor(x) + " " + (int) Math.floor(yy) + " " + (int) Math.floor(z)
                    : String.format("XYZ %.1f %.1f %.1f", x, yy, z);
            y = pill(g, mc.font, t, 6, y, false);
        }
        if (ModuleManager.SPEED.enabled) {
            double bps = mc.player.getDeltaMovement().horizontalDistance() * 20.0;
            y = pill(g, mc.font, String.format("%.1f BPS", bps), 6, y, false);
        }
        if (ModuleManager.CLOCK.enabled) {
            boolean h24 = ModuleManager.CLOCK.setting("24 часа");
            y = pill(g, mc.font, LocalTime.now().format(h24 ? CLOCK_24 : CLOCK_12), 6, y, false);
        }
    }

    /** Плашка с текстом, возвращает y следующей плашки. */
    private static int pill(GuiGraphics g, Font font, String text, int x, int y, boolean accent) {
        int w = font.width(text) + 12;
        Draw.rrect(g, x, y, w, 16, 4, 0xC0101114);
        if (accent) g.fill(x + 3, y + 4, x + 5, y + 12, Draw.ACCENT);
        g.drawString(font, text, x + (accent ? 9 : 6), y + 4, Draw.TEXT);
        return y + 20;
    }

    // ---- броня справа ----

    private static void drawArmor(GuiGraphics g, Minecraft mc) {
        int w = g.guiWidth();
        int h = g.guiHeight();
        boolean durability = ModuleManager.ARMOR.setting("Показывать прочность");
        int x = w - 26;
        int y = h / 2 - 36;
        Draw.rrect(g, x - 4, y - 4, 26, 4 * 18 + 6, 5, 0xC0101114);
        for (int i = 0; i < ARMOR_SLOTS.length; i++) {
            ItemStack stack = mc.player.getItemBySlot(ARMOR_SLOTS[i]);
            if (stack.isEmpty()) continue;
            g.renderItem(stack, x, y + i * 18);
            if (durability) g.renderItemDecorations(mc.font, stack, x, y + i * 18);
        }
    }

    // ---- клавиши внизу слева ----

    private static void drawKeys(GuiGraphics g, Minecraft mc) {
        int cell = 20;
        int gap = 2;
        int h = g.guiHeight();
        boolean mouse = ModuleManager.KEYS.setting("Показывать мышь");
        int rows = mouse ? 4 : 3;
        int baseX = 6;
        int baseY = h - 6 - rows * (cell + gap) + gap;

        var o = mc.options;
        key(g, mc.font, "W", o.keyUp, baseX + cell + gap, baseY, cell, cell);
        key(g, mc.font, "A", o.keyLeft, baseX, baseY + cell + gap, cell, cell);
        key(g, mc.font, "S", o.keyDown, baseX + cell + gap, baseY + cell + gap, cell, cell);
        key(g, mc.font, "D", o.keyRight, baseX + 2 * (cell + gap), baseY + cell + gap, cell, cell);
        key(g, mc.font, "SPACE", o.keyJump, baseX, baseY + 2 * (cell + gap), 3 * cell + 2 * gap, cell);
        if (mouse) {
            int half = (3 * cell + 2 * gap - gap) / 2;
            keyState(g, mc.font, "LMB", mc.mouseHandler.isLeftPressed(), baseX, baseY + 3 * (cell + gap), half, cell);
            keyState(g, mc.font, "RMB", mc.mouseHandler.isRightPressed(), baseX + half + gap, baseY + 3 * (cell + gap), half, cell);
        }
    }

    private static void key(GuiGraphics g, Font font, String label, KeyMapping mapping, int x, int y, int w, int h) {
        keyState(g, font, label, mapping.isDown(), x, y, w, h);
    }

    private static void keyState(GuiGraphics g, Font font, String label, boolean down, int x, int y, int w, int h) {
        Draw.rrectBordered(g, x, y, w, h, 4, down ? Draw.ACCENT_SOFT : 0xC0101114, down ? Draw.ACCENT : Draw.CARD_BORDER);
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, down ? Draw.TEXT : Draw.TEXT_DIM);
    }

    // ---- цель у прицела ----

    private static void drawTarget(GuiGraphics g, Minecraft mc) {
        if (!(mc.crosshairPickEntity instanceof LivingEntity target)) return;
        Font font = mc.font;
        String name = target.getName().getString();
        float hp = Math.max(0f, target.getHealth());
        float max = Math.max(1f, target.getMaxHealth());
        String hpText = String.format("%.1f / %.1f", hp, max);

        int w = Math.max(110, Math.max(font.width(name), font.width(hpText)) + 16);
        int x = g.guiWidth() / 2 + 16;
        int y = g.guiHeight() / 2 + 10;
        Draw.rrectBordered(g, x, y, w, 38, 5, 0xD0101114, Draw.CARD_BORDER);
        g.drawString(font, name, x + 8, y + 6, Draw.TEXT);
        g.drawString(font, hpText, x + 8, y + 17, Draw.TEXT_DIM);

        float ratio = Math.min(1f, hp / max);
        int barW = w - 16;
        Draw.rrect(g, x + 8, y + 28, barW, 4, 2, Draw.SWITCH_OFF);
        int fill = Math.max(2, Math.round(barW * ratio));
        int color = ratio > 0.5f ? 0xFF3DDC84 : ratio > 0.25f ? 0xFFFFC53D : 0xFFFF5252;
        Draw.rrect(g, x + 8, y + 28, fill, 4, 2, color);
    }
}
