package lostvisuals;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/** Экранные модули: Watermark, FPS Counter, Coordinates. */
public final class Hud {
    private Hud() {}

    public static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("lostvisuals", "hud"), (graphics, deltaTracker) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            // Не мешаем собственному меню и другим экранам поверх мира.
            int y = 6;
            if (ModuleManager.WATERMARK.enabled) {
                String t = "Lost Visuals";
                if (ModuleManager.WATERMARK.setting("Показывать версию")) t += " 1.21.11";
                y = pill(graphics, mc.font, t, 6, y, true);
            }
            if (ModuleManager.FPS.enabled) {
                y = pill(graphics, mc.font, mc.getFps() + " FPS", 6, y, false);
            }
            if (ModuleManager.COORDS.enabled) {
                boolean round = ModuleManager.COORDS.setting("Округлять");
                String t = round
                        ? "XYZ " + (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ())
                        : String.format("XYZ %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
                pill(graphics, mc.font, t, 6, y, false);
            }
        });
    }

    /** Плашка с текстом, возвращает y следующей плашки. */
    private static int pill(GuiGraphics g, Font font, String text, int x, int y, boolean accent) {
        int w = font.width(text) + 12;
        Draw.rrect(g, x, y, w, 16, 4, 0xC0101114);
        if (accent) g.fill(x + 3, y + 4, x + 5, y + 12, Draw.ACCENT);
        g.drawString(font, text, x + (accent ? 9 : 6), y + 4, Draw.TEXT);
        return y + 20;
    }
}
