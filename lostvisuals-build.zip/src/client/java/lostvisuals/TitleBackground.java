package lostvisuals;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;

/** Фото на фоне главного экрана: рисуется поверх панорамы, но под кнопками. */
public final class TitleBackground {
    private TitleBackground() {}

    private static final Identifier PHOTO = Identifier.fromNamespaceAndPath("lostvisuals", "textures/gui/title_bg.png");
    private static final int TEX_W = 435;
    private static final int TEX_H = 438;

    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof TitleScreen)) return;
            ScreenEvents.afterBackground(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> {
                if (!ModuleManager.TITLE_PHOTO.enabled) return;
                int w = graphics.guiWidth();
                int h = graphics.guiHeight();
                // cover: заполняем экран целиком, лишнее уходит за края
                double scale = Math.max(w / (double) TEX_W, h / (double) TEX_H);
                int dw = (int) Math.ceil(TEX_W * scale);
                int dh = (int) Math.ceil(TEX_H * scale);
                int dx = (w - dw) / 2;
                int dy = (h - dh) / 2;
                graphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, PHOTO, dx, dy, 0f, 0f, dw, dh, TEX_W, TEX_H, TEX_W, TEX_H);
                graphics.fill(0, 0, w, h, 0x50000000);
            });
        });
    }
}
