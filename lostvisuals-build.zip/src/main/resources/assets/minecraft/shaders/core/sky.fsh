#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec3 lostDir;

out vec4 fragColor;

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float vnoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i);
    float n100 = hash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
               mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + vec3(7.1, 3.7, 5.3);
        a *= 0.5;
    }
    return v;
}

void main() {
    vec3 base = ColorModulator.rgb;
    float lum = dot(base, vec3(0.299, 0.587, 0.114));
    vec3 col = base;

    // Только верхний купол неба. Нижний диск (под горизонтом) остаётся ванильным.
    if (lostDir.y > 0.0) {
        vec3 d = normalize(lostDir);
        float up = clamp(d.y, 0.0, 1.0);

        // Градиент: у горизонта светлее и теплее, к зениту глубже.
        vec3 horizon = base + vec3(0.10, 0.07, 0.13) * (0.4 + lum);
        vec3 zenith = base * 0.82;
        col = mix(horizon, zenith, pow(up, 0.55));

        // Ночью: туманность и полярное сияние. Чем темнее небо, тем сильнее эффект.
        float night = 1.0 - smoothstep(0.04, 0.30, lum);
        if (night > 0.001) {
            float neb = smoothstep(0.45, 0.85, fbm(d * 3.0));
            vec3 nebColor = mix(vec3(0.20, 0.10, 0.45), vec3(0.05, 0.35, 0.60), fbm(d * 2.0 + 11.0));
            float band = sin(d.x * 5.0 + fbm(d * 4.0) * 6.0) * 0.5 + 0.5;
            float aur = smoothstep(0.55, 1.0, band) * smoothstep(0.05, 0.35, up) * (1.0 - smoothstep(0.35, 0.75, up));
            // Неоновая туманность с холодным фиолетово-бирюзовым акцентом.
            col += nebColor * neb * 0.62 * night;
            col += vec3(0.10, 0.90, 0.72) * aur * 0.42 * night;

            // Мелкие звёзды: редкие яркие точки в направлении взгляда.
            vec3 starCell = floor(d * 520.0);
            float starSeed = hash13(starCell);
            float star = step(0.9972, starSeed) * smoothstep(0.15, 0.75, up);
            float twinkle = 0.65 + 0.35 * sin(float(int(starSeed * 900.0)) + lum * 18.0);
            col += vec3(0.72, 0.82, 1.0) * star * twinkle * night;

            // Лёгкий металлический блик у горизонта.
            float rim = pow(1.0 - up, 5.0) * (1.0 - smoothstep(0.0, 0.18, up));
            col += vec3(0.24, 0.16, 0.42) * rim * (0.25 + 0.35 * night);
        }
    }

    fragColor = apply_fog(vec4(clamp(col, 0.0, 1.0), ColorModulator.a), sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
