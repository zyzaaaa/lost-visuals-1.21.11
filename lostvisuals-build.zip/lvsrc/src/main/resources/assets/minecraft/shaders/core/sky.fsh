#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec3 lostDir;

out vec4 fragColor;

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash13(i);
    float b = hash13(i + vec3(1.0, 0.0, 0.0));
    float c = hash13(i + vec3(0.0, 1.0, 0.0));
    float d = hash13(i + vec3(1.0, 1.0, 0.0));
    float e = hash13(i + vec3(0.0, 0.0, 1.0));
    float f1 = hash13(i + vec3(1.0, 0.0, 1.0));
    float g = hash13(i + vec3(0.0, 1.0, 1.0));
    float h = hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, f1, f.x), mix(g, h, f.x), f.y), f.z);
}

float fbm(vec3 p) {
    float sum = 0.0;
    float amplitude = 0.5;
    for (int i = 0; i < 4; i++) {
        sum += noise3(p) * amplitude;
        p = p * 2.02 + vec3(13.1, 7.7, 5.3);
        amplitude *= 0.5;
    }
    return sum;
}

void main() {
    // Apply vanilla fog first; add LostVisuals colors after it so FogColor cannot wash them out.
    vec4 vanillaSky = apply_fog(ColorModulator, sphericalVertexDistance,
        cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);

    vec3 color = vanillaSky.rgb;
    vec3 direction = normalize(lostDir);
    float up = clamp(direction.y, 0.0, 1.0);

    float horizonFade = pow(1.0 - up, 1.35);
    vec3 horizonTint = vec3(0.12, 0.045, 0.20);
    vec3 zenithTint = vec3(0.025, 0.07, 0.22);
    color += mix(zenithTint, horizonTint, horizonFade) * 0.22;

    float luminance = dot(vanillaSky.rgb, vec3(0.2126, 0.7152, 0.0722));
    float night = 1.0 - smoothstep(0.07, 0.28, luminance);

    float clouds = fbm(direction * 5.0 + vec3(2.0, 0.0, 4.0));
    float nebula = smoothstep(0.43, 0.78, clouds);
    vec3 nebulaColor = mix(vec3(0.34, 0.055, 0.72), vec3(0.025, 0.34, 0.78),
        fbm(direction * 3.2 + vec3(8.0, 3.0, 1.0)));
    color += nebulaColor * nebula * night * 0.72;

    float wave = 0.24 + 0.075 * sin(direction.x * 7.0 + direction.z * 4.0);
    float auroraShape = 1.0 - smoothstep(0.015, 0.12, abs(up - wave));
    float auroraNoise = smoothstep(0.30, 0.78, fbm(direction * 8.0 + vec3(1.0, 6.0, 2.0)));
    vec3 auroraColor = mix(vec3(0.02, 0.95, 0.58), vec3(0.20, 0.32, 1.0), direction.x * 0.5 + 0.5);
    color += auroraColor * auroraShape * auroraNoise * night * 0.58;

    fragColor = vec4(clamp(color, vec3(0.0), vec3(1.0)), vanillaSky.a);
}
