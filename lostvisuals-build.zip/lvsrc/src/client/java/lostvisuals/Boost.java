package lostvisuals;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

/**
 * FPS Boost: переключает настройки графики на минимальную нагрузку, исходные значения хранит в
 * config/lostvisuals-boost-backup.json и возвращает при выключении. Ничего не меняет в рендере напрямую.
 */
public final class Boost {
    private Boost() {}

    public static final String[] SETTINGS = {
            "Дальность прорисовки 8",
            "Дистанция симуляции 5",
            "Дальность сущностей 0.75",
            "Минимум частиц",
            "Без облаков",
            "Без теней сущностей",
            "Без сглаженного освещения",
            "Быстрая листва",
            "Без улучшенной прозрачности",
            "Чанки без плавного появления",
            "Без смешивания биомов",
            "Меньше погодных эффектов",
            "Без виньетки",
            "Без VSync",
            "Без лимита FPS"
    };

    private record Tweak(String setting, Consumer<JsonObject> save, Consumer<JsonObject> restore, Runnable apply) {}

    private static Path backupPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("lostvisuals-boost-backup.json");
    }

    private static JsonObject readBackup() {
        Path p = backupPath();
        if (!Files.isRegularFile(p)) return null;
        try {
            return JsonParser.parseString(Files.readString(p)).getAsJsonObject();
        } catch (IOException | RuntimeException e) {
            LostVisualsClient.LOG.warn("Не удалось прочитать резервную копию настроек: {}", e.toString());
            return null;
        }
    }

    private static void writeBackup(JsonObject o) {
        try {
            Files.writeString(backupPath(), o.toString());
        } catch (IOException e) {
            LostVisualsClient.LOG.warn("Не удалось записать резервную копию настроек: {}", e.toString());
        }
    }

    private static void deleteBackup() {
        try {
            Files.deleteIfExists(backupPath());
        } catch (IOException e) {
            LostVisualsClient.LOG.warn("Не удалось удалить резервную копию настроек: {}", e.toString());
        }
    }

    // ---- конструкторы твиков ----

    private static Tweak intCap(String setting, String key, OptionInstance<Integer> opt, int cap) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get()),
                b -> { if (b.has(key)) opt.set(b.get(key).getAsInt()); },
                () -> { if (opt.get() > cap) opt.set(cap); });
    }

    private static Tweak intSet(String setting, String key, OptionInstance<Integer> opt, int value) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get()),
                b -> { if (b.has(key)) opt.set(b.get(key).getAsInt()); },
                () -> opt.set(value));
    }

    private static Tweak doubleCap(String setting, String key, OptionInstance<Double> opt, double cap) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get()),
                b -> { if (b.has(key)) opt.set(b.get(key).getAsDouble()); },
                () -> { if (opt.get() > cap) opt.set(cap); });
    }

    private static Tweak doubleSet(String setting, String key, OptionInstance<Double> opt, double value) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get()),
                b -> { if (b.has(key)) opt.set(b.get(key).getAsDouble()); },
                () -> opt.set(value));
    }

    private static Tweak boolSet(String setting, String key, OptionInstance<Boolean> opt, boolean value) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get()),
                b -> { if (b.has(key)) opt.set(b.get(key).getAsBoolean()); },
                () -> opt.set(value));
    }

    private static <E extends Enum<E>> Tweak enumSet(String setting, String key, OptionInstance<E> opt, E value, Class<E> type) {
        return new Tweak(setting,
                b -> b.addProperty(key, opt.get().name()),
                b -> {
                    if (!b.has(key)) return;
                    try {
                        opt.set(Enum.valueOf(type, b.get(key).getAsString()));
                    } catch (IllegalArgumentException ignored) {
                        // значение из старой версии игры, оставляем как есть
                    }
                },
                () -> opt.set(value));
    }

    private static List<Tweak> tweaks(Options o) {
        List<Tweak> t = new ArrayList<>();
        t.add(intCap(SETTINGS[0], "renderDistance", o.renderDistance(), 8));
        t.add(intCap(SETTINGS[1], "simulationDistance", o.simulationDistance(), 5));
        t.add(doubleCap(SETTINGS[2], "entityDistanceScaling", o.entityDistanceScaling(), 0.75));
        t.add(enumSet(SETTINGS[3], "particles", o.particles(), ParticleStatus.MINIMAL, ParticleStatus.class));
        t.add(enumSet(SETTINGS[4], "cloudStatus", o.cloudStatus(), CloudStatus.OFF, CloudStatus.class));
        t.add(boolSet(SETTINGS[5], "entityShadows", o.entityShadows(), false));
        t.add(boolSet(SETTINGS[6], "ambientOcclusion", o.ambientOcclusion(), false));
        t.add(boolSet(SETTINGS[7], "cutoutLeaves", o.cutoutLeaves(), false));
        t.add(boolSet(SETTINGS[8], "improvedTransparency", o.improvedTransparency(), false));
        t.add(doubleSet(SETTINGS[9], "chunkSectionFadeInTime", o.chunkSectionFadeInTime(), 0.0));
        t.add(intSet(SETTINGS[10], "biomeBlendRadius", o.biomeBlendRadius(), 0));
        t.add(intSet(SETTINGS[11], "weatherRadius", o.weatherRadius(), 3));
        t.add(boolSet(SETTINGS[12], "vignette", o.vignette(), false));
        t.add(boolSet(SETTINGS[13], "enableVsync", o.enableVsync(), false));
        t.add(intSet(SETTINGS[14], "framerateLimit", o.framerateLimit(), 260));
        return t;
    }

    /** Применяет текущее состояние модуля: возвращает исходные настройки и, если модуль включён, применяет выбранные. */
    public static void sync() {
        Options o = Minecraft.getInstance().options;
        if (o == null) return;
        try {
            List<Tweak> all = tweaks(o);
            JsonObject backup = readBackup();
            if (backup != null) {
                for (Tweak t : all) t.restore().accept(backup);
            }
            Module m = ModuleManager.BOOST;
            if (m.enabled) {
                JsonObject fresh = new JsonObject();
                for (Tweak t : all) t.save().accept(fresh);
                writeBackup(fresh);
                for (Tweak t : all) {
                    if (m.setting(t.setting())) t.apply().run();
                }
            } else {
                deleteBackup();
            }
            o.save();
        } catch (RuntimeException e) {
            LostVisualsClient.LOG.warn("FPS Boost: не удалось изменить настройки: {}", e.toString());
        }
    }

    /** При запуске: если модуль включён, а резервной копии нет (первый запуск), применяем сразу. */
    public static void startup() {
        if (ModuleManager.BOOST.enabled && readBackup() == null) sync();
    }
}
