package lostvisuals;

/** Настройка с выбором из списка значений: клик в меню переключает на следующее. */
public final class ChoiceSetting {
    public final String name;
    public final String[] options;
    public int index;

    public ChoiceSetting(String name, String[] options, int index) {
        this.name = name;
        this.options = options;
        this.index = Math.max(0, Math.min(options.length - 1, index));
    }

    public String current() {
        return options[index];
    }

    public void next() {
        index = (index + 1) % options.length;
    }
}
