package lostvisuals;

/** Применяет выбранный стиль и акцентный цвет к палитре. Rainbow пересчитывается каждый кадр через tick(). */
public final class Theme {
    private Theme() {}

    private static final int[] ACCENTS = {
            0xFF2EA8FF, 0xFFA855F7, 0xFF34D399, 0xFFFF5252, 0xFFFF5FA2, 0xFFFFA63D
    };
    private static boolean rainbow = false;
    private static int accentIndex = 0;

    public static void apply() {
        Module m = ModuleManager.THEME;
        if (m == null || !m.enabled) {
            Draw.styleId = 0;
            rainbow = false;
            accentIndex = 0;
        } else {
            Draw.styleId = m.choiceIndex("Стиль");
            int a = m.choiceIndex("Акцент");
            rainbow = a >= ACCENTS.length;
            accentIndex = rainbow ? 0 : a;
        }
        tick();
    }

    /** Вызывать перед рисованием кадра: обновляет цвет акцента (для Rainbow он меняется со временем). */
    public static void tick() {
        int color = rainbow ? hsv((System.currentTimeMillis() % 6000L) / 6000f) : ACCENTS[accentIndex];
        Draw.ACCENT = color;
        Draw.ACCENT_SOFT = Draw.withAlpha(color, 0x33);
    }

    /** HSV (насыщенность и яркость максимальны) в ARGB, без java.awt. */
    private static int hsv(float h) {
        float x = h * 6f;
        int i = (int) Math.floor(x);
        float f = x - i;
        float q = 1f - f;
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = 1f; g = f; b = 0f; }
            case 1 -> { r = q; g = 1f; b = 0f; }
            case 2 -> { r = 0f; g = 1f; b = f; }
            case 3 -> { r = 0f; g = q; b = 1f; }
            case 4 -> { r = f; g = 0f; b = 1f; }
            default -> { r = 1f; g = 0f; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
