package lostvisuals;

import net.minecraft.client.gui.GuiGraphics;

/** Мелкие помощники рисования и палитра. Цвета в формате ARGB. */
public final class Draw {
    private Draw() {}

    public static int WINDOW_BG = 0xF2101114;
    public static int WINDOW_BORDER = 0xFF26272C;
    public static int SIDEBAR_BG = 0xFF0D0E10;
    public static int CARD_BG = 0xFF17181C;
    public static int CARD_BORDER = 0xFF25272C;
    public static int TEXT = 0xFFF2F3F5;
    public static int TEXT_DIM = 0xFF8A8D94;
    public static int ACCENT = 0xFF2EA8FF;
    public static int ACCENT_SOFT = 0x332EA8FF;
    public static int SWITCH_OFF = 0xFF3A3C42;
    public static int KNOB = 0xFFE9EAEE;
    public static int BUTTON_BG = 0xFF1B1C20;

    /** Скруглённый прямоугольник: только углы строками, середина одним fill. */
    public static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            g.fill(x, y, x + w, y + h, color);
            return;
        }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    // ---- стили поверхностей ----

    public static final int L_WINDOW = 0;
    public static final int L_CARD = 1;
    public static final int L_HUD = 2;

    /** 0 Default, 1 Neon, 2 Metallic, 3 Glass. Выставляется из Theme. */
    public static int styleId = 0;

    public static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, aa = (a >>> 24) & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255, ba = (b >>> 24) & 255;
        int r = (int) (ar + (br - ar) * t);
        int gr = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        int al = (int) (aa + (ba - aa) * t);
        return (al << 24) | (r << 16) | (gr << 8) | bl;
    }

    /** Мягкое свечение вокруг прямоугольника: несколько слоёв с малой прозрачностью. */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int r, int color, int layers, int alphaStep) {
        for (int i = layers; i >= 1; i--) {
            rrect(g, x - i, y - i, w + 2 * i, h + 2 * i, r + i, withAlpha(color, alphaStep * (layers - i + 1)));
        }
    }

    /** Скруглённый прямоугольник с вертикальным градиентом. */
    public static void gradientRRect(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, lerpColor(top, bottom, i / (float) h));
            int yb = y + h - 1 - i;
            g.fill(x + inset, yb, x + w - inset, yb + 1, lerpColor(top, bottom, (h - 1 - i) / (float) h));
        }
        g.fillGradient(x, y + r, x + w, y + h - r, lerpColor(top, bottom, r / (float) h), lerpColor(top, bottom, (h - r) / (float) h));
    }

    /** Поверхность окна, карточки или плашки HUD в текущем стиле. */
    public static void surface(GuiGraphics g, int x, int y, int w, int h, int r, int level, boolean hover) {
        switch (styleId) {
            case 1 -> { // Neon
                int glowA = level == L_WINDOW ? 10 : (hover ? 18 : 8);
                if (level != L_CARD || hover) glow(g, x, y, w, h, r, ACCENT, level == L_WINDOW ? 4 : 3, glowA);
                int fill = level == L_HUD ? 0xD0070810 : (level == L_WINDOW ? 0xF2080910 : (hover ? 0xFF11131A : 0xFF0C0D12));
                rrectBordered(g, x, y, w, h, r, fill, withAlpha(ACCENT, level == L_CARD && !hover ? 0x88 : 0xFF));
            }
            case 2 -> { // Metallic
                int top = level == L_WINDOW ? 0xFF3A3F47 : (hover ? 0xFF3C424B : 0xFF343941);
                int bottom = level == L_WINDOW ? 0xFF1B1E23 : 0xFF21252B;
                int border = hover ? 0xFFB4BBC6 : 0xFF7C8491;
                if (level == L_HUD) {
                    top = 0xE0434952;
                    bottom = 0xE02A2E35;
                }
                rrect(g, x, y, w, h, r, border);
                gradientRRect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), top, bottom);
                g.fill(x + r, y + 1, x + w - r, y + 2, 0x55FFFFFF);
            }
            case 3 -> { // Glass
                rrect(g, x, y, w, h, r, level == L_WINDOW ? 0x70101520 : 0x60101520);
                rrect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), hover ? 0x38FFFFFF : 0x24FFFFFF);
                g.fill(x + r, y + 1, x + w - r, y + 2, 0x66FFFFFF);
            }
            default -> {
                if (level == L_HUD) {
                    rrect(g, x, y, w, h, r, 0xC0101114);
                } else if (level == L_WINDOW) {
                    rrectBordered(g, x, y, w, h, r, WINDOW_BG, WINDOW_BORDER);
                } else {
                    rrectBordered(g, x, y, w, h, r, hover ? 0xFF1B1C21 : CARD_BG, CARD_BORDER);
                }
            }
        }
    }

    /** Скруглённый прямоугольник с рамкой 1px. */
    public static void rrectBordered(GuiGraphics g, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(g, x, y, w, h, r, border);
        rrect(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    /** Переключатель-«таблетка» 22x12. */
    public static void toggle(GuiGraphics g, int x, int y, boolean on) {
        rrect(g, x, y, 22, 12, 6, on ? ACCENT : SWITCH_OFF);
        int kx = on ? x + 12 : x + 2;
        rrect(g, kx, y + 2, 8, 8, 4, KNOB);
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
